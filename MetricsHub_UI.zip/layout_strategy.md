# Layout Strategy – MetricsHub

**CSS Grid sinh ra để làm Layout tổng thể, Flexbox sinh ra để làm Component chi tiết.**

- **Navbar** dùng **Flexbox** vì đây là không gian 1 chiều (hàng ngang). Các phần tử (Logo – Menu – Profile) chỉ cần căn chỉnh theo trục chính và khoảng cách linh hoạt theo nội dung. Khi chữ dài (tiếng Đức), Flexbox tự giãn/thu mà không bị tràn.

- **Dashboard (Bento Box)** dùng **CSS Grid** vì cần kiểm soát 2 chiều (hàng + cột). Widget lớn chiếm đúng `span 2` cột và `span 2` hàng một cách tự nhiên. Không cần lồng Flexbox nhiều tầng (Div Soup).

- **Pricing** dùng **Bootstrap Grid** (`col-md-4`) vì yêu cầu đơn giản: 3 cột bằng nhau trên Desktop, xếp chồng trên Mobile. Thư viện đã xử lý sẵn responsive, giúp triển khai nhanh và đồng bộ với hệ thống.
