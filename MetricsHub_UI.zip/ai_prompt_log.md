# AI Prompt Log – MetricsHub UI Refactor

## Prompt 1 – Phân biệt 1D vs 2D
**Câu hỏi:** Khi tôi cần một bố cục mà một phần tử con phải chiếm chính xác 2 hàng và 2 cột (span 2 rows, 2 columns) đan xen với các phần tử nhỏ khác, tôi nên chọn CSS Grid hay Flexbox? Tại sao Flexbox lại chật vật với yêu cầu này?

**Kết quả nhận được:** CSS Grid vì nó là hệ thống 2 chiều. Flexbox chỉ kiểm soát 1 trục tại một thời điểm; muốn giả lập span 2×2 phải dùng nhiều lớp lồng nhau và tính toán height thủ công → dễ vỡ.

## Prompt 2 – Bootstrap breakpoints
**Câu hỏi:** Trong Bootstrap 5, sự khác biệt giữa lớp `col-sm-4` và `col-md-4` là gì? Tại sao nên dùng Bootstrap thay vì tự viết CSS Grid cho 3 cột Pricing?

**Kết quả nhận được:** `col-sm-4` áp dụng từ ≥576px, `col-md-4` từ ≥768px. Bootstrap giúp triển khai nhanh, đồng bộ responsive, giảm media query thủ công.

## Prompt 3 – Bento Box syntax
**Câu hỏi:** Hãy cho tôi xem cú pháp CSS Grid đơn giản (dùng span) để tạo layout Bento Box: 1 hình vuông lớn bên trái chiếm 2×2, và các hình vuông nhỏ bên phải.

**Kết quả nhận được:**  
```css
.dashboard { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
.widget-large { grid-column: span 2; grid-row: span 2; }
```

## Prompt 4 – Flex-wrap Navbar
**Câu hỏi:** Làm thế nào để Navbar dùng Flexbox trên mobile tự động đẩy menu xuống dòng mà không che Logo?

**Kết quả nhận được:** Thêm `flex-wrap: wrap` và `gap` cho `.navbar`. Khi không đủ chỗ, các item tự xuống dòng giữ thứ tự đọc.

## Prompt 5 – Kết hợp Flex + Grid
**Câu hỏi:** Flexbox và CSS Grid có thể kết hợp không? Ví dụ trong widget đang nằm trong Grid, muốn căn giữa icon + chữ thì dùng gì?

**Kết quả nhận được:** Có thể kết hợp. Bên trong `.widget` (Grid item) dùng `display: flex; justify-content: center; align-items: center;` để căn nội dung 1D.
